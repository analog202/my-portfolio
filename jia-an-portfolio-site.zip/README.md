# jia an's portfolio 2026

Static site: `index.html` plus the `img/` folder. No build step.

## Publish with GitHub Pages
1. Create a repo and upload everything in this folder (index.html at the top level).
2. Settings > Pages > Source: Deploy from a branch > main / (root).
3. Your site appears at `https://<username>.github.io/<repo>/`.
